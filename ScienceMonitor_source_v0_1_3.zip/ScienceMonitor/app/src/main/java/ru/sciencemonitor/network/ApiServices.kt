package ru.sciencemonitor.network

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Query

interface OpenAlexService {
    @GET("works")
    suspend fun searchWorks(
        @Query("search") query: String,
        @Query("per-page") perPage: Int = 50
    ): OpenAlexResponse
}

interface CrossrefService {
    @GET("works")
    suspend fun searchWorks(
        @Query("query") query: String,
        @Query("rows") rows: Int = 50
    ): CrossrefResponse
}

// Все поля nullable: Gson обходит значения по умолчанию Kotlin, если в JSON пришёл null.

data class OpenAlexResponse(
    val results: List<OpenAlexWork>? = null
)

data class OpenAlexWork(
    val id: String? = null,
    val doi: String? = null,
    val title: String? = null,
    @SerializedName("publication_year") val publicationYear: Int? = null,
    @SerializedName("publication_date") val publicationDate: String? = null,
    val authorships: List<OpenAlexAuthorship>? = null,
    @SerializedName("primary_location") val primaryLocation: OpenAlexLocation? = null,
    @SerializedName("abstract_inverted_index") val abstractInvertedIndex: Map<String, List<Int>>? = null
)

data class OpenAlexAuthorship(val author: OpenAlexAuthor? = null)
data class OpenAlexAuthor(@SerializedName("display_name") val displayName: String? = null)
data class OpenAlexLocation(val source: OpenAlexSource? = null)
data class OpenAlexSource(@SerializedName("display_name") val displayName: String? = null)

data class CrossrefResponse(val message: CrossrefMessage? = null)
data class CrossrefMessage(val items: List<CrossrefWork>? = null)

data class CrossrefWork(
    @SerializedName("DOI") val doi: String? = null,
    val title: List<String>? = null,
    val author: List<CrossrefAuthor>? = null,
    val published: CrossrefDate? = null,
    val issued: CrossrefDate? = null,
    @SerializedName("container-title") val containerTitle: List<String>? = null,
    @SerializedName("URL") val url: String? = null,
    val abstract: String? = null
)

data class CrossrefAuthor(val given: String? = null, val family: String? = null)

// Crossref иногда отдаёт [[null]], поэтому элементы nullable.
data class CrossrefDate(
    @SerializedName("date-parts") val dateParts: List<List<Int?>?>? = null
)
