package ru.sciencemonitor.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class WeeklySearchWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val dao = ScienceDatabase.get(applicationContext).publicationDao()
        val summary = PublicationRepository(dao).searchAll()

        // Повторяем только если не ответил ни один источник, и не бесконечно.
        return if (summary.failedSources.size >= 2 && runAttemptCount < 3) {
            Result.retry()
        } else {
            Result.success()
        }
    }
}
