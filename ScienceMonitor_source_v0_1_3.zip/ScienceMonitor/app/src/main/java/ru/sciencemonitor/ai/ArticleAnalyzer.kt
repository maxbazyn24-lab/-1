package ru.sciencemonitor.ai

import ru.sciencemonitor.data.Publication

/**
 * Контракт анализатора. Реализация локальной языковой модели будет добавлена
 * после проверки объёма RAM, свободного хранилища и архитектуры процессора телефона.
 */
interface ArticleAnalyzer {
    suspend fun analyze(publication: Publication): ArticleAnalysis
}

data class ArticleAnalysis(
    val researchObjective: String?,
    val objectOfStudy: String?,
    val methods: String?,
    val mainFindings: String?,
    val scientificNovelty: String?,
    val geographicArea: String?,
    val relevanceToThesis: String?,
    val limitations: String?,
    val evidenceBasis: String,
    val confidenceNote: String
)
