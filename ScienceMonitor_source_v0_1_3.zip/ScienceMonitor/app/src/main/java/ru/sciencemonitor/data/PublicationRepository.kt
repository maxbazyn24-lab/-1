package ru.sciencemonitor.data

import kotlin.coroutines.cancellation.CancellationException
import ru.sciencemonitor.network.ApiFactory

data class SearchSummary(val added: Int, val failedSources: List<String>)

class PublicationRepository(private val dao: PublicationDao) {

    companion object {
        const val DEFAULT_QUERY = "Palaemon macrodactylus"
    }

    /** Запрашивает все источники независимо: сбой одного не отменяет другой. */
    suspend fun searchAll(query: String = DEFAULT_QUERY): SearchSummary {
        var added = 0
        val failed = mutableListOf<String>()

        try {
            added += searchOpenAlex(query)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            failed += "OpenAlex"
        }

        try {
            added += searchCrossref(query)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            failed += "Crossref"
        }

        return SearchSummary(added, failed)
    }

    /** Возвращает число НОВЫХ записей, добавленных в базу. */
    suspend fun searchOpenAlex(query: String): Int {
        val response = ApiFactory.openAlex.searchWorks(query = query)
        val publications = response.results.orEmpty().mapNotNull { work ->
            val title = work.title?.trim()?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            val doi = normalizeDoi(work.doi)
            val key = doi ?: title.lowercase()

            Publication(
                deduplicationKey = key,
                title = title,
                authors = work.authorships.orEmpty()
                    .mapNotNull { it.author?.displayName }
                    .joinToString("; "),
                publicationYear = work.publicationYear,
                journal = work.primaryLocation?.source?.displayName.orEmpty(),
                doi = doi,
                abstractText = rebuildAbstract(work.abstractInvertedIndex),
                landingPageUrl = doi?.let { "https://doi.org/$it" } ?: work.id,
                source = "OpenAlex"
            )
        }
        return insertCountingNew(publications)
    }

    suspend fun searchCrossref(query: String): Int {
        val response = ApiFactory.crossref.searchWorks(query = query)
        val publications = response.message?.items.orEmpty().mapNotNull { work ->
            val title = work.title?.firstOrNull()?.trim()?.takeIf { it.isNotEmpty() }
                ?: return@mapNotNull null
            val doi = normalizeDoi(work.doi)
            val key = doi ?: title.lowercase()
            val year = (work.published ?: work.issued)
                ?.dateParts?.firstOrNull()?.firstOrNull()

            Publication(
                deduplicationKey = key,
                title = title,
                authors = work.author.orEmpty().mapNotNull {
                    listOfNotNull(it.given, it.family).joinToString(" ").ifBlank { null }
                }.joinToString("; "),
                publicationYear = year,
                journal = work.containerTitle?.firstOrNull().orEmpty(),
                doi = doi,
                abstractText = stripTags(work.abstract),
                landingPageUrl = work.url,
                source = "Crossref"
            )
        }
        return insertCountingNew(publications)
    }

    private suspend fun insertCountingNew(items: List<Publication>): Int {
        if (items.isEmpty()) return 0
        // Убираем дубли внутри самой выдачи, затем считаем реально вставленные.
        return dao.insertAll(items.distinctBy { it.deduplicationKey }).count { it != -1L }
    }

    private fun normalizeDoi(raw: String?): String? =
        raw?.trim()
            ?.replace(Regex("^https?://(dx\\.)?doi\\.org/", RegexOption.IGNORE_CASE), "")
            ?.lowercase()
            ?.takeIf { it.isNotEmpty() }

    /** OpenAlex хранит аннотацию как «слово -> позиции»; собираем текст обратно. */
    private fun rebuildAbstract(index: Map<String, List<Int>>?): String {
        if (index.isNullOrEmpty()) return ""
        val words = ArrayList<Pair<Int, String>>()
        for ((word, positions) in index) {
            for (p in positions) words.add(p to word)
        }
        return words.sortedBy { it.first }.joinToString(" ") { it.second }
    }

    /** Аннотации Crossref приходят в JATS-XML; убираем теги. */
    private fun stripTags(raw: String?): String =
        raw.orEmpty().replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()
}
