package ru.sciencemonitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.launch
import ru.sciencemonitor.data.Publication
import ru.sciencemonitor.data.PublicationRepository
import ru.sciencemonitor.data.ScienceDatabase
import ru.sciencemonitor.data.SearchScheduler

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SearchScheduler.scheduleWeekly(this)

        setContent {
            MaterialTheme {
                ScienceMonitorHome()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScienceMonitorHome() {
    val context = LocalContext.current
    val dao = remember { ScienceDatabase.get(context).publicationDao() }
    val repository = remember { PublicationRepository(dao) }
    val publicationsFlow = remember { dao.observeAll() }
    val publications by publicationsFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var status by remember { mutableStateOf("Ожидает первого поиска") }
    var running by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Science Monitor") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Научный мониторинг", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "Текущая тема: Palaemon macrodactylus и экология Азовского моря",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Автоматический поиск", style = MaterialTheme.typography.titleMedium)
                        Text("Каждый понедельник. Фоновый запуск может задерживаться Android.")
                        Spacer(Modifier.height(8.dp))
                        Text("Статус: $status")
                        Spacer(Modifier.height(8.dp))
                        Button(
                            enabled = !running,
                            onClick = {
                                running = true
                                status = "Идёт поиск…"
                                scope.launch {
                                    status = try {
                                        val result = repository.searchAll()
                                        val failed = if (result.failedSources.isEmpty()) ""
                                        else ". Не ответили: ${result.failedSources.joinToString()}"
                                        "Добавлено новых записей: ${result.added}$failed"
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Exception) {
                                        "Ошибка поиска: ${e.message ?: e.javaClass.simpleName}"
                                    } finally {
                                        running = false
                                    }
                                }
                            }
                        ) {
                            Text("Запустить поиск")
                        }
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Источники", style = MaterialTheme.typography.titleMedium)
                        Text("Работают: OpenAlex · Crossref")
                        Text(
                            "Пока не подключены: Semantic Scholar · eLIBRARY.RU. " +
                                "Для eLIBRARY нужна отдельная проверка разрешённого доступа.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                Text(
                    "Библиотека (${publications.size})",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            items(publications, key = { it.deduplicationKey }) { pub ->
                PublicationCard(pub)
            }
        }
    }
}

@Composable
private fun PublicationCard(pub: Publication) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                pub.title,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            if (pub.authors.isNotBlank()) {
                Text(
                    pub.authors,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            val meta = listOfNotNull(
                pub.journal.takeIf { it.isNotBlank() },
                pub.publicationYear?.toString(),
                pub.source
            ).joinToString(" · ")
            Text(meta, style = MaterialTheme.typography.bodySmall)
            pub.doi?.let { Text("DOI: $it", style = MaterialTheme.typography.bodySmall) }
        }
    }
}
