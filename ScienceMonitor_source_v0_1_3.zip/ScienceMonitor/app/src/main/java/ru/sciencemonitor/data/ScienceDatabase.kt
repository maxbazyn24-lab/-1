package ru.sciencemonitor.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Publication::class],
    version = 1,
    exportSchema = false
)
abstract class ScienceDatabase : RoomDatabase() {
    abstract fun publicationDao(): PublicationDao

    companion object {
        @Volatile private var INSTANCE: ScienceDatabase? = null

        fun get(context: Context): ScienceDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ScienceDatabase::class.java,
                    "science_monitor.db"
                ).build().also { INSTANCE = it }
            }
    }
}
