package ru.sciencemonitor.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PublicationDao {
    /** Возвращает rowId для каждой записи; -1 означает, что запись уже была в базе. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<Publication>): List<Long>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: Publication): Long

    @Query("SELECT * FROM publications ORDER BY dateAddedUtc DESC")
    fun observeAll(): Flow<List<Publication>>

    @Query("SELECT COUNT(*) FROM publications")
    suspend fun count(): Int

    @Query("SELECT * FROM publications WHERE deduplicationKey = :key LIMIT 1")
    suspend fun findByKey(key: String): Publication?
}
