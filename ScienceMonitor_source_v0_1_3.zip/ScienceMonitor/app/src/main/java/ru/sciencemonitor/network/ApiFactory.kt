package ru.sciencemonitor.network

import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiFactory {
    // Crossref и OpenAlex просят указывать идентифицируемый User-Agent.
    private const val USER_AGENT = "ScienceMonitor/0.1.2 (Android; research monitoring app)"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header("User-Agent", USER_AGENT)
                        .build()
                )
            }
            .build()
    }

    val openAlex: OpenAlexService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.openalex.org/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OpenAlexService::class.java)
    }

    val crossref: CrossrefService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.crossref.org/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CrossrefService::class.java)
    }
}
